import * as types from '../actions/types';

const initialState = {
  // Assuming single source of truth for user data:
  user: [], // Or a default user object if needed
  ownerId: null,
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.REGISTER_USER:
      return {
        ...state,
        user: action.payload,
      };
    case types.LOGIN_USER:
      return {
        ...state,
        user: action.payload,
      };
    case types.LOGOUT_USER:
      return {
        ...state,
        user: null,
      };
      case types.POSTDATA:
      return {
        ...state,
        user: action.payload,
      };
    case types.STORE_OWNER_ID:
      return {
        ...state,
        ownerId: action.payload,
      };
    // PERSIST_USER_DATA case removed as persistence is handled elsewhere
    default:
      return state;
  }
};

export default userReducer;