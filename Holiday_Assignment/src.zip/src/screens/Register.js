// Register.js
import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { useDispatch } from 'react-redux';
import { registerUser } from '../redux/actions/actions';

const Register = ({ navigation }) => {
  const dispatch = useDispatch();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');

  const handleRegister = () => {
    dispatch(registerUser(firstName, lastName, email));
    navigation.navigate('Login'); // Navigate back to the Login screen after registration
  };

  return (
    <View style={styles.mainContainer}>
      <View style={styles.headingText}>
        <Text style={styles.register}>Register</Text>
        <Text style={styles.account}>Create your account</Text>
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.inputStyle}
          placeholder="First Name"
          value={firstName}
          onChangeText={text => setFirstName(text)}
        />

        <TextInput
          style={styles.inputStyle}
          placeholder="Second Name"
          value={lastName}
          onChangeText={text => setLastName(text)}
        />
        <TextInput
          style={styles.inputStyle}
          placeholder="Email"
          autoCapitalize="none"
          value={email}
          onChangeText={text => setEmail(text)}
          keyboardType="email-address"
        />
        <TouchableOpacity
          onPress={handleRegister}
          style={styles.registerButton}>
          <Text style={styles.registerButtonText}>Register</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: 'lightgrey',
    justifyContent: 'space-between',
    padding: 20,
  },
  headingText: {
    flex: 0.25,
    backgroundColor: 'lightblue',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    marginBottom: 20,
  },
  register: {
    color: 'black',
    fontSize: 40,
    fontWeight: 'bold',
  },
  account: {
    color: 'black',
    fontSize: 18,
  },
  inputContainer: {
    backgroundColor: 'white',
    flex: 0.75,
    justifyContent: 'space-evenly',
    borderRadius: 10,
    padding: 20,
  },
  inputStyle: {
    paddingLeft: 15,
    backgroundColor: 'white',
    borderRadius: 10,
    marginBottom: 20,
    height: 50,
    borderWidth: 1,
    borderColor: 'lightgrey',
  },
  registerButton: {
    backgroundColor: 'blue',
    borderRadius: 10,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  registerButtonText: {
    fontSize: 18,
    color: 'white',
    fontWeight: 'bold',
  },
});

export default Register;